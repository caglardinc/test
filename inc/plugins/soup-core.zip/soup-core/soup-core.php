<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://wowtheme.net/sajib
 * @since             1.0.2
 * @package           Soup_Core
 *
 * @wordpress-plugin
 * Plugin Name:       Soup Core
 * Plugin URI:        http://wowtheme.net
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.2
 * Author:            Sajib Talukder
 * Author URI:        http://wowtheme.net/sajib
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       soup-core
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


define('SOUP_CORE_URL', plugin_dir_url(__FILE__) ); 
define('SOUP_CORE_PATH', plugin_dir_path( __FILE__) ); 

/************************************************************************
 * Load plugin textdomain.
 ************************************************************************/ 
function soup_textdomain() {
	load_plugin_textdomain( 'soup-core', false, basename( dirname( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'soup_textdomain' );
 

define('APFSURL', WP_PLUGIN_URL."/".dirname( plugin_basename( __FILE__ ) ) );
define('APFPATH', WP_PLUGIN_DIR."/".dirname( plugin_basename( __FILE__ ) ) );
function soup_enqueuescripts()
{
    wp_enqueue_script('soupreview', APFSURL.'/js/soupreview.js', array('jquery'));
    wp_localize_script( 'soupreview', 'soupajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );


	wp_register_script( 'accounting', WC()->plugin_url() . '/assets/js/accounting/accounting.js', array( 'jquery' ), '0.4.2' );

	wp_enqueue_script( 'woocommerce-addons', APFSURL. '/woocommerce-product-addons/assets/js/addons.js', array(), '1.0', true );


	$params = array(
		'price_display_suffix'         => esc_attr( get_option( 'woocommerce_price_display_suffix' ) ),
		'ajax_url'                     => WC()->ajax_url(),
		'i18n_addon_total'             => __( 'Options total:', 'woocommerce-product-addons' ),
		'i18n_grand_total'             => __( 'Grand total:', 'woocommerce-product-addons' ),
		'i18n_remaining'               => __( 'characters remaining', 'woocommerce-product-addons' ),
		'currency_format_num_decimals' => absint( get_option( 'woocommerce_price_num_decimals' ) ),
		'currency_format_symbol'       => get_woocommerce_currency_symbol(),
		'currency_format_decimal_sep'  => esc_attr( stripslashes( get_option( 'woocommerce_price_decimal_sep' ) ) ),
		'currency_format_thousand_sep' => esc_attr( stripslashes( get_option( 'woocommerce_price_thousand_sep' ) ) ),
	);

	if ( ! function_exists( 'get_woocommerce_price_format' ) ) {
		$currency_pos = get_option( 'woocommerce_currency_pos' );

		switch ( $currency_pos ) {
			case 'left' :
				$format = '%1$s%2$s';
				break;
			case 'right' :
				$format = '%2$s%1$s';
				break;
			case 'left_space' :
				$format = '%1$s&nbsp;%2$s';
				break;
			case 'right_space' :
				$format = '%2$s&nbsp;%1$s';
				break;
		}

		$params['currency_format'] = esc_attr( str_replace( array( '%1$s', '%2$s' ), array( '%s', '%v' ), $format ) );
	} else {
		$params['currency_format'] = esc_attr( str_replace( array( '%1$s', '%2$s' ), array( '%s', '%v' ), get_woocommerce_price_format() ) );
	}

	wp_localize_script( 'woocommerce-addons', 'woocommerce_addons_params', $params );

	
}
add_action('wp_enqueue_scripts', 'soup_enqueuescripts');
/**
 * Post Type 
 */
require plugin_dir_path( __FILE__ ) . 'includes/post-type.php';

/**
 * Taxonomy
 */
require plugin_dir_path( __FILE__ ) . 'includes/taxonomy.php';

/**
 * Shortcode
 */
require plugin_dir_path( __FILE__ ) . 'includes/shortcodes.php';

/**
 * switcer css
 */
require plugin_dir_path( __FILE__ ) . 'includes/switcher-css.php';

/**
 * Load About Widget File
 */  
require plugin_dir_path( __FILE__ ) . 'includes/widgets/soup-about-widget.php';

/**
 * Load Newsletter Widget File
 */  
require plugin_dir_path( __FILE__ ) . 'includes/widgets/soup-newsletter-widget.php';

/**
 * One Click Demo Import
 */
// require plugin_dir_path( __FILE__ ) . 'one-click-demo/init.php';
require plugin_dir_path( __FILE__ ) . 'one-click-demo-import/one-click-demo-import.php';

/**
 * woocommerce product add on
 */
 //require plugin_dir_path( __FILE__ ) . 'woocommerce-product-addons/woocommerce-product-addons.php';

/**
 * ajax variable add to cart
 */
// require plugin_dir_path( __FILE__ ) . 'woocommerce-ajax-add-to-cart-variable-products/woocommerce-ajax-add-to-cart-variable-products.php';

 
// admin area css
function soup_admin_styles() {
   ?>
    <style type="text/css">
    	.rs-update-notice-wrap,
    	.redux-timer,
    	#wpfooter #footer-left,
    	.redux-dev-qtip,
        .rAds span a img,
        .redux-notice,
        #redux_blast_1454922210,
		#admin_config{
			display: none !important;
		}
		.field-menuposition .edit-menu-item-menuposition,
		.field-mtype .edit-menu-item-mtype,
		.field-column .edit-menu-item-column{
			width: 100px;
		}
		ul#menu-to-edit li.menu-item-depth-6 .hidn,
		ul#menu-to-edit li.menu-item-depth-5 .hidn,
		ul#menu-to-edit li.menu-item-depth-4 .hidn,
		ul#menu-to-edit li.menu-item-depth-3 .hidn,
		ul#menu-to-edit li.menu-item-depth-2 .field-enablemegamenu, 
		ul#menu-to-edit li.menu-item-depth-2 .field-mtype ,
		ul#menu-to-edit li.menu-item-depth-2 .field-column , 
		ul#menu-to-edit li.menu-item-depth-1 .cs-fieldset, 
		ul#menu-to-edit li.menu-item-depth-1 .field-mtype ,
		ul#menu-to-edit li.menu-item-depth-1 .field-column ,
		ul#menu-to-edit li.menu-item-depth-1 .field-enablemegamenu ,
		ul#menu-to-edit li.menu-item-depth-0 .cs-fieldset , 
		ul#menu-to-edit li.menu-item-depth-0 .field-columntitle{
			display: none;
		}
		.menu-item-settings {
		    overflow: hidden;
		}
		.field-mimg img#upimage {
		    width: 100px;
		    max-height: 100px; 
		}
    </style>
    <?php
}
add_action('admin_head', 'soup_admin_styles');

// frontend css
function soup_frontend_styles() {
	global $soup;
   ?>
    <style type="text/css">
		.soup-confirm {
		    position: fixed;
		    left: 50%;
		    top: 50%;
		    background: #ddd;
		    padding: 40px;
		    border-radius: 3px;
		    z-index: 9999;
		    display: none;
		    margin-top: -4%;
		    margin-left: -9%;
		}
		.soup-confirm:before {
			font-family: WooCommerce;
		    content: '\e017';
		    margin-left: .53em;
		    vertical-align: bottom;
		}

		.slick-track .content-inner h1{
			font-size: <?php echo (!empty($soup['slider-title-fsize'])) ? ($soup['slider-title-fsize']) : ''; ?>;
			font-weight: <?php echo (!empty($soup['slider-title-fwet'])) ? ($soup['slider-title-fwet']) : ''; ?>; 
		}
		.slick-track .content-inner h4,
		.slick-track .content-inner h5{
			font-size: <?php echo (!empty($soup['slider-title2-fsize'])) ? ($soup['slider-title2-fsize']) : ''; ?>;
			font-weight:<?php echo (!empty($soup['slider-title2-fwet'])) ? ($soup['slider-title2-fwet']) : ''; ?>;
			color: <?php echo (!empty($soup['slider-title2-colr']['rgba'])) ? ($soup['slider-title2-colr']['rgba'].' !important') : ''; ?>   ;
		}

		/* store opening-closing */
		.mt65{
			margin-top: 65px;
		}
		.store-close-notice{
		    width: 100%;
		    height: 65px;
		    background: #99e699;
		    position: fixed;
		    left: 0;
		    right: 0;
		    top: 0;
		    z-index: 99999;
		}
		.store-close-notice span{
		    color: red;
		    padding: 16px;
		    display: block;
		    text-align: center;
		    font-size: 20px;
		}
		<?php $user = wp_get_current_user();
		$allowed_roles = array( 'administrator');
		if( array_intersect($allowed_roles, $user->roles ) ):  ?>  
			.store-close-notice{ 
			    top: 32px; 
			}
		<?php endif; ?>



    </style>
    <?php
}
add_action('wp_head', 'soup_frontend_styles');



/**
 * Post Formate Display Procedure.
 */
add_action('admin_print_scripts', 'soup_display_procedure', 1000);

function soup_display_procedure(){ ?> 
	<?php if(get_post_type() == 'page') : ?>
		<script>
			jQuery(document).ready(function(){
				var id = jQuery( 'input[name="_soup_pg_bnr_typ"]:checked' ).attr('id');  
				if(id == '_soup_pg_bnr_typ1'){
					jQuery('.cmb2-id--soup-page-banner').show();  
				}else{
					jQuery('.cmb2-id--soup-page-banner').hide();  
				}
				if((id == '_soup_pg_bnr_typ1') || (id == '_soup_pg_bnr_typ2')){ 
					jQuery('.cmb2-id--soup-page-banner-title').show(); 
					jQuery('.cmb2-id--soup-page-banner-subtitle').show(); 
					jQuery('.cmb2-id--soup-page-banner-txtclr').show(); 
				}else{ 
					jQuery('.cmb2-id--soup-page-banner-title').hide(); 
					jQuery('.cmb2-id--soup-page-banner-subtitle').hide(); 
					jQuery('.cmb2-id--soup-page-banner-txtclr').hide(); 
				}
				if(id == '_soup_pg_bnr_typ2'){
					jQuery('.cmb2-id--soup-page-banner-clr').show(); 
				}else{
					jQuery('.cmb2-id--soup-page-banner-clr').hide();  
				}
				if(id == '_soup_pg_bnr_typ3'){
					jQuery('.cmb2-id--soup-pg-slider-styl').show(); 
					jQuery('.cmb2-id--soup-page-psldr-cat').show(); 
				}else{
					jQuery('.cmb2-id--soup-pg-slider-styl').hide(); 
					jQuery('.cmb2-id--soup-page-psldr-cat').hide(); 
				} 
				if(id == '_soup_pg_bnr_typ4'){
					jQuery('.cmb2-id--soup-rev-slider-alias').show(); 
				}else{
					jQuery('.cmb2-id--soup-rev-slider-alias').hide(); 
				} 
				if(id == '_soup_pg_bnr_typ5'){
					jQuery('.cmb2-id--soup-page-vdo-logo').show(); 
					jQuery('.cmb2-id--soup-page-vdo-title').show(); 
					jQuery('.cmb2-id--soup-page-vdo-subtitle').show(); 
					jQuery('.cmb2-id--soup-page-vdo-bgurl').show(); 
					jQuery('.cmb2-id--soup-page-vdo-btntxt').show(); 
					jQuery('.cmb2-id--soup-page-vdo-btnlink').show(); 
				}else{
					jQuery('.cmb2-id--soup-page-vdo-logo').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-title').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-subtitle').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-bgurl').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-btntxt').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-btnlink').hide(); 
				} 

				jQuery( 'input[name="_soup_pg_bnr_typ"]' ).change(function(){ 
					jQuery('.cmb2-id--soup-page-banner').hide();
					jQuery('.cmb2-id--soup-pg-slider-styl').hide(); 
					jQuery('.cmb2-id--soup-page-psldr-cat').hide(); 
					jQuery('.cmb2-id--soup-rev-slider-alias').hide();  
					jQuery('.cmb2-id--soup-page-banner-title').hide();  
					jQuery('.cmb2-id--soup-page-banner-subtitle').hide();  
					jQuery('.cmb2-id--soup-page-banner-txtclr').hide();
					jQuery('.cmb2-id--soup-page-vdo-logo').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-title').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-subtitle').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-bgurl').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-btntxt').hide(); 
					jQuery('.cmb2-id--soup-page-vdo-btnlink').hide(); 

					var id = jQuery( 'input[name="_soup_pg_bnr_typ"]:checked' ).attr('id'); 
 
					if(id == '_soup_pg_bnr_typ1'){
						jQuery('.cmb2-id--soup-page-banner').show();  
					}else{
						jQuery('.cmb2-id--soup-page-banner').hide();  
					}
					if((id == '_soup_pg_bnr_typ1') || (id == '_soup_pg_bnr_typ2')){ 
						jQuery('.cmb2-id--soup-page-banner-title').show(); 
						jQuery('.cmb2-id--soup-page-banner-subtitle').show(); 
						jQuery('.cmb2-id--soup-page-banner-txtclr').show(); 
					}else{ 
						jQuery('.cmb2-id--soup-page-banner-title').hide(); 
						jQuery('.cmb2-id--soup-page-banner-subtitle').hide(); 
						jQuery('.cmb2-id--soup-page-banner-txtclr').hide(); 
					}

					if(id == '_soup_pg_bnr_typ2'){
						jQuery('.cmb2-id--soup-page-banner-clr').show(); 
					}else{
						jQuery('.cmb2-id--soup-page-banner-clr').hide(); 
					}
					if(id == '_soup_pg_bnr_typ3'){
						jQuery('.cmb2-id--soup-pg-slider-styl').show(); 
						jQuery('.cmb2-id--soup-page-psldr-cat').show(); 
					}else{
						jQuery('.cmb2-id--soup-pg-slider-styl').hide(); 
						jQuery('.cmb2-id--soup-page-psldr-cat').hide(); 
					}
					if(id == '_soup_pg_bnr_typ4'){
						jQuery('.cmb2-id--soup-rev-slider-alias').show(); 
					}else{
						jQuery('.cmb2-id--soup-rev-slider-alias').hide(); 
					} 
					if(id == '_soup_pg_bnr_typ5'){
						jQuery('.cmb2-id--soup-page-vdo-logo').show(); 
						jQuery('.cmb2-id--soup-page-vdo-title').show(); 
						jQuery('.cmb2-id--soup-page-vdo-subtitle').show(); 
						jQuery('.cmb2-id--soup-page-vdo-bgurl').show(); 
						jQuery('.cmb2-id--soup-page-vdo-btntxt').show(); 
						jQuery('.cmb2-id--soup-page-vdo-btnlink').show(); 
					}else{
						jQuery('.cmb2-id--soup-page-vdo-logo').hide(); 
						jQuery('.cmb2-id--soup-page-vdo-title').hide(); 
						jQuery('.cmb2-id--soup-page-vdo-subtitle').hide(); 
						jQuery('.cmb2-id--soup-page-vdo-bgurl').hide(); 
						jQuery('.cmb2-id--soup-page-vdo-btntxt').hide(); 
						jQuery('.cmb2-id--soup-page-vdo-btnlink').hide(); 
					} 
  
				});
			})
		</script> 
	<?php endif; ?>
<?php }


function soup_addreviews() {
    $results = '';
  
    $rv_comment =  $_POST['pcoment']; 
    $rv_star = $_POST['pstar']; 
    $rv_name = $_POST['pname']; 
    $rv_email = $_POST['pemail']; 
    $rv_desig = $_POST['pcompany']; 
 

	$rvw_slug = str_replace(" ", "-", strtolower($rv_name));

    $post_id = wp_insert_post(array(
	    'post_title'    =>   $rv_name,
	    'post_name'    =>   $rvw_slug, 
	    'post_content'  =>   $rv_comment, 
	    'post_status'   =>   'pending',           // Choose: publish, preview, future, draft, etc.
	    'post_type' =>   'reviews'  //'post',page' or use a custom post type if you want to
	    ));
 
	//insert custom fields
	update_post_meta($post_id,'_soup_revie_design',$_POST['pcompany']);
	update_post_meta($post_id,'_soup_revie_email',$_POST['pemail']); 
	update_post_meta($post_id,'_soup_revie_rat',$_POST['pstar']); 

    if ( $post_id != 0 ) {
        $results = '*Post Added';
    }
    else {
        $results = '*Error occured while adding the post';
    }
    // Return the String
    die($results);
}
// creating Ajax call for WordPress
add_action( 'wp_ajax_nopriv_soup_addreviews', 'soup_addreviews' );
add_action( 'wp_ajax_soup_addreviews', 'soup_addreviews' );


// boooking form
function soup_sentemail() {
    $results = 'hello';
	  
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	    // form data
	    $soup_name = $_POST['name'];
	    $soup_email = $_POST['email'];
	    $soup_phone = $_POST['phone'];
	    $soup_date = $_POST['date'];
	    $soup_attendents = $_POST['attendents'];
	    $soup_sentTO = $_POST['senttomail'];
	    $soupSub = $_POST['senttitle'];
	    $soupFrom = $_POST['sentfrom'];
	 
	    if(''!=$soup_name || ''!=$soup_email || ''!=$soup_phone || ''!=$soup_date || ''!=$soup_attendents ){
	        // http_response_code(403);
	        $results =  'Please Fill Out All Fields.';
	       // exit;
	    }
	    $soup_mail_to = $soup_sentTO;
	    $soup_mail_sub = $soupSub;
	    $soup_mail_from = $soupFrom;

	    $soup_mail_msg = "Reservation Details\n";
	    $soup_mail_msg .= "Name: ".$soup_name."\n";
	    $soup_mail_msg .= "Email: ".$soup_email."\n";  
	    $soup_mail_msg .= "Phone: ".$soup_phone."\n";  
	    $soup_mail_msg .= "Date: ".$soup_date."\n";  
	    $soup_mail_msg .= "Attendents: ".$soup_attendents."\n";   
	    $soup_mail_headers = "From: ".$soup_mail_sub." <".$soup_mail_from.">" . "\r\n"; 

	    if(wp_mail($soup_mail_to,$soup_mail_sub,$soup_mail_msg,$soup_mail_headers)){
	       // http_response_code(200);
	        $results =  "Thank you for booking! We will get back to you as soon as possible";
	    }else{
	       // http_response_code(500);
	        $results =  "There was a problem";
	    }
	}else{
	   // http_response_code(403);
	    $results =  "There was a problem";
	}

    // Return the String
    die($results);
}
// creating Ajax call for WordPress
add_action( 'wp_ajax_nopriv_soup_sentemail', 'soup_sentemail' );
add_action( 'wp_ajax_soup_sentemail', 'soup_sentemail' );



function soup_add_to_cart_confirm(){
	?>
	<div class="soup-confirm">
		 Product added to cart.
	</div>
	<?php
}
add_action('wp_footer','soup_add_to_cart_confirm');

	
