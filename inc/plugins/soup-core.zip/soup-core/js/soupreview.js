(function ($) {

    "use strict";
 $( document ).ready(function() {

    var $soupreviewform  = $('#soupreviewform');

    if($soupreviewform.length>0) {
        
        $soupreviewform.submit(function(e){
            e.preventDefault(); 
            var $btn = $(this).find('.btn-submit');
            var star = $(this).find(".star:checked").val();
            var name = $(this).find('.name').val();
            var email = $(this).find('.email').val();
            var company = $(this).find('.company').val();
            var coment = $(this).find('.coment').val(); 
            if(name !='' || email != '' || company !='' || coment != ''){
                if ($soupreviewform.valid()){
                    $btn.addClass('loading');
                    $.ajax({
                        type: 'post',
                        url: soupajax.ajaxurl,
                        data:  {
                            action: 'soup_addreviews',
                            pstar: star,
                            pname: name, 
                            pemail: email, 
                            pcompany: company, 
                            pcoment: coment 
                        }
                    }).done(function(response){
                        if(response){
                            $btn.addClass('success');
                        } else {
                            $btn.addClass('error');
                        }
                        console.log(response);
                    }).fail(function(data){
                        console.log(data);
                        setTimeout(function(){ $btn.addClass('error'); }, 1200); 

                    }).complete(function(data){
                        console.log(data);
                        setTimeout(function(){
                            $btn.removeClass('loading error success');
                        },6000);

                    });
                    return false;
                } 
            }
        });

    }

        // Contact Form
    var $bookingForm  = $('#booking-form');

    if($bookingForm.length>0) {
        
        $bookingForm.submit(function(e){
            e.preventDefault();
            var formData = $bookingForm.serialize();
            var $btn = $(this).find('.btn-submit');
            var senttomail = $(this).find('.senttomail').val();
            var senttitle = $(this).find('.senttitle').val();
            var sentfrom = $(this).find('.sentfrom').val();
            var name = $(this).find('.name').val();
            var email = $(this).find('.email').val();
            var phone = $(this).find('.phone').val();
            var date = $(this).find('.date').val();
            var attendents = $(this).find('.attendents').val();  
            
            if ($bookingForm.valid()){
                $btn.addClass('loading');
                $.ajax({
                    type: 'post',
                    url: soupajax.ajaxurl,
                    data:  {
                        action: 'soup_sentemail',
                        senttomail: senttomail,
                        senttitle: senttitle, 
                        sentfrom: sentfrom, 
                        name: name, 
                        email: email, 
                        phone: phone, 
                        date: date, 
                        attendents: attendents 
                    } 
                }).done(function(response){
                    if(response){
                        $btn.addClass('success');
                    } else {
                        $btn.addClass('error');
                    }
                }).fail(function(data){
                    setTimeout(function(){ $btn.addClass('error'); }, 1200); 

                }).complete(function(data){
                    setTimeout(function(){
                        $btn.removeClass('loading error success');
                    },6000);

                });
                return false;
            } 
        });
    }

});

})(jQuery);

 